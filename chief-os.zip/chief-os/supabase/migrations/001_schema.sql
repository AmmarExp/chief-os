-- Enable UUID extension
create extension if not exists "pgcrypto";

-- ════════════════════════════════
-- profiles
-- ════════════════════════════════
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  telegram_chat_id bigint,
  telegram_link_code text,
  telegram_link_code_expires_at timestamptz,
  created_at timestamptz default now()
);
alter table public.profiles enable row level security;
create policy "profiles_self" on public.profiles using (auth.uid() = id) with check (auth.uid() = id);

-- ════════════════════════════════
-- agents
-- ════════════════════════════════
create table if not exists public.agents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  name text not null,
  role text,
  model text default 'gemini-2.0-flash',
  system_prompt text,
  soul_prompt text,
  memory_context text,
  is_chief boolean default false,
  status text default 'idle',
  autonomy integer default 50,
  emoji text default '🤖',
  color text default '#01696f',
  updated_at timestamptz default now(),
  created_at timestamptz default now()
);
alter table public.agents enable row level security;
create policy "agents_self" on public.agents using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- tasks
-- ════════════════════════════════
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  agent_id uuid references public.agents(id) on delete set null,
  title text not null,
  description text,
  priority text default 'medium',
  status text default 'queued',
  is_recurring boolean default false,
  recur_interval text,
  next_run_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now()
);
alter table public.tasks enable row level security;
create policy "tasks_self" on public.tasks using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- task_outputs
-- ════════════════════════════════
create table if not exists public.task_outputs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  task_id uuid references public.tasks(id) on delete cascade,
  agent_id uuid references public.agents(id) on delete set null,
  stage integer default 1,
  content text,
  created_at timestamptz default now()
);
alter table public.task_outputs enable row level security;
create policy "outputs_self" on public.task_outputs using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- chief_messages
-- ════════════════════════════════
create table if not exists public.chief_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  direction text not null,
  text text not null,
  context_type text,
  context_id uuid,
  telegram_message_id bigint,
  created_at timestamptz default now()
);
alter table public.chief_messages enable row level security;
create policy "messages_self" on public.chief_messages using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- notes
-- ════════════════════════════════
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  content text,
  summary text,
  domain text default 'personal',
  revision_history jsonb default '[]'::jsonb,
  updated_at timestamptz default now(),
  created_at timestamptz default now()
);
alter table public.notes enable row level security;
create policy "notes_self" on public.notes using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- calendar_events
-- ════════════════════════════════
create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  event_date date not null,
  event_time time,
  all_day boolean default false,
  domain text default 'personal',
  created_at timestamptz default now()
);
alter table public.calendar_events enable row level security;
create policy "events_self" on public.calendar_events using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- chief_memory
-- ════════════════════════════════
create table if not exists public.chief_memory (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  content text not null,
  category text default 'fact',
  source text default 'manual',
  created_at timestamptz default now()
);
alter table public.chief_memory enable row level security;
create policy "memory_self" on public.chief_memory using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- agent_logs
-- ════════════════════════════════
create table if not exists public.agent_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  agent_id uuid references public.agents(id) on delete cascade,
  action text not null,
  detail text,
  created_at timestamptz default now()
);
alter table public.agent_logs enable row level security;
create policy "logs_self" on public.agent_logs using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ════════════════════════════════
-- Realtime
-- ════════════════════════════════
alter publication supabase_realtime add table public.chief_messages;

-- ════════════════════════════════
-- Auto-create profile + default agents
-- ════════════════════════════════
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email);
  insert into public.agents (user_id, name, role, model, emoji, color, is_chief) values
    (new.id, 'Chief', 'Personal AI Assistant', 'gemini-2.0-flash', '👑', '#01696f', true),
    (new.id, 'Atlas', 'Researcher & Analyst', 'gemini-2.0-flash', '🗺️', '#006494', false),
    (new.id, 'Quill', 'Writer & Content Creator', 'gemini-2.0-flash', '✍️', '#7a39bb', false),
    (new.id, 'Vega', 'Data & Code Specialist', 'gemini-2.0-flash', '⚡', '#437a22', false);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
