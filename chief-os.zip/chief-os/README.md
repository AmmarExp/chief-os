# Chief OS 👑

> Your personal AI command center.

## Stack

- **Frontend**: React + TypeScript + Vite + TailwindCSS
- **Backend**: Supabase (Auth, Database, Realtime)
- **AI**: Gemini 2.0 Flash (via Supabase Edge Functions)
- **Messaging**: Telegram Bot

## Setup

```bash
npm install
cp .env.example .env
npm run dev
```

## Supabase

Run `supabase/migrations/001_schema.sql` in the Supabase SQL Editor to set up all tables, RLS policies, and triggers.

## Pages

| Page | Path |
|------|------|
| Dashboard | `#dashboard` |
| Chief Chat | `#chief` |
| Tasks | `#tasks` |
| Notes | `#notes` |
| Calendar | `#calendar` |
| Agents | `#agents` |
| Outputs | `#outputs` |
| Memory | `#memory` |
| Soul | `#soul` |
| Skills | `#skills` |
| Logs | `#logs` |
| Settings | `#settings` |
