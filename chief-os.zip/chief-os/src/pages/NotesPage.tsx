import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog } from '@/components/ui/dialog'
import { domainBadge } from '@/components/ui/badge'
import { Plus, Trash2, Pencil, History, X } from 'lucide-react'
import { formatDateTime } from '@/lib/utils'

export function NotesPage() {
  const { user } = useAuth()
  const [notes, setNotes] = useState<any[]>([])
  const [domain, setDomain] = useState('all')
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [historyNote, setHistoryNote] = useState<any>(null)
  const [form, setForm] = useState({ title:'', content:'', domain:'personal', summary:'' })
  const [loading, setLoading] = useState(true)

  const load = async () => {
    if (!user) return
    const { data } = await supabase.from('notes').select('*').eq('user_id', user.id).order('updated_at', { ascending: false })
    setNotes(data || [])
    setLoading(false)
  }
  useEffect(() => { load() }, [user])

  const save = async () => {
    if (!user || !form.title.trim()) return
    const now = new Date().toISOString()
    if (editing) {
      const prev = editing.revision_history || []
      const newHistory = [...prev, { content: editing.content, saved_at: now }].slice(-20)
      await supabase.from('notes').update({ ...form, updated_at: now, revision_history: newHistory }).eq('id', editing.id)
    } else {
      await supabase.from('notes').insert({ ...form, user_id: user.id, revision_history: [] })
    }
    setOpen(false); setEditing(null); setForm({ title:'', content:'', domain:'personal', summary:'' }); load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this note?')) return
    await supabase.from('notes').delete().eq('id', id)
    setNotes(prev => prev.filter(n => n.id !== id))
  }

  const openEdit = (n: any) => { setEditing(n); setForm({ title:n.title, content:n.content, domain:n.domain, summary:n.summary||'' }); setOpen(true) }

  const filtered = domain === 'all' ? notes : notes.filter(n => n.domain === domain)

  if (loading) return <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{[...Array(6)].map((_,i) => <div key={i} className="skeleton h-36 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-5xl">
      <div className="flex items-center justify-between mb-5">
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Notes</h1><p className="text-sm text-[var(--color-text-muted)]">{filtered.length} notes</p></div>
        <Button variant="primary" size="sm" onClick={() => { setEditing(null); setForm({ title:'', content:'', domain:'personal', summary:'' }); setOpen(true) }}><Plus size={15} />New Note</Button>
      </div>
      <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-xs mb-4 w-fit">
        {['all','work','projects','personal'].map(d => <button key={d} onClick={() => setDomain(d)} className={`px-3 py-1.5 capitalize transition-colors ${domain===d?'bg-[var(--color-primary)] text-white':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{d}</button>)}
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]"><NoteIcon /><p className="mt-2">No notes yet. Create your first note.</p></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(n => (
            <div key={n.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-sm font-semibold text-[var(--color-text)] line-clamp-1">{n.title}</h3>
                <div className="flex gap-1 shrink-0">
                  {(n.revision_history||[]).length > 0 && <button onClick={() => setHistoryNote(n)} className="p-1 text-[var(--color-text-faint)] hover:text-[var(--color-text-muted)]"><History size={13}/></button>}
                  <button onClick={() => openEdit(n)} className="p-1 text-[var(--color-text-faint)] hover:text-[var(--color-text-muted)]"><Pencil size={13}/></button>
                  <button onClick={() => del(n.id)} className="p-1 text-[var(--color-text-faint)] hover:text-red-400"><Trash2 size={13}/></button>
                </div>
              </div>
              {n.summary && <p className="text-xs text-[var(--color-primary)] font-medium">{n.summary}</p>}
              <p className="text-xs text-[var(--color-text-muted)] line-clamp-3 flex-1">{n.content}</p>
              <div className="flex items-center justify-between mt-1">{domainBadge(n.domain)}<span className="text-xs text-[var(--color-text-faint)]">{formatDateTime(n.updated_at)}</span></div>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onClose={() => { setOpen(false); setEditing(null) }} title={editing ? 'Edit Note' : 'New Note'} width="max-w-2xl">
        <div className="space-y-3">
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Title *</label><Input value={form.title} onChange={e => setForm(p => ({...p,title:e.target.value}))} placeholder="Note title" /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Summary</label><Input value={form.summary} onChange={e => setForm(p => ({...p,summary:e.target.value}))} placeholder="Short summary (optional)" /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Content</label><Textarea value={form.content} onChange={e => setForm(p => ({...p,content:e.target.value}))} placeholder="Write your note..." rows={8} /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Domain</label>
            <select value={form.domain} onChange={e => setForm(p => ({...p,domain:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              {['work','projects','personal'].map(d => <option key={d} value={d}>{d}</option>)}</select></div>
          <div className="flex gap-2 pt-2"><Button variant="secondary" className="flex-1" onClick={() => { setOpen(false); setEditing(null) }}>Cancel</Button><Button variant="primary" className="flex-1" onClick={save}>Save Note</Button></div>
        </div>
      </Dialog>
      {historyNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setHistoryNote(null)} />
          <div className="relative bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-5 max-w-lg w-full max-h-[70vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-3"><h3 className="font-semibold text-[var(--color-text)]">Revision History</h3><button onClick={() => setHistoryNote(null)} className="p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"><X size={15}/></button></div>
            {([...(historyNote.revision_history||[])].reverse()).map((r: any, i: number) => (
              <div key={i} className="border-b border-[var(--color-border)] py-2 last:border-0">
                <div className="text-xs text-[var(--color-text-faint)] mb-1">{formatDateTime(r.saved_at)}</div>
                <p className="text-xs text-[var(--color-text-muted)] line-clamp-4">{r.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
function NoteIcon() { return <svg className="w-10 h-10 mx-auto text-[var(--color-text-faint)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg> }
