import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Crown } from 'lucide-react'

export function AuthPage() {
  const [mode, setMode] = useState<'login'|'register'>('login')
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false); const [error, setError] = useState('')

  const handle = async () => {
    setLoading(true); setError('')
    try {
      const { error: e } = mode === 'login'
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password })
      if (e) setError(e.message)
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--color-bg)] px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-[var(--color-primary)] flex items-center justify-center mb-4">
            <Crown size={28} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-[var(--color-text)]">Chief OS</h1>
          <p className="text-sm text-[var(--color-text-muted)] mt-1">Your personal AI operating system</p>
        </div>
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 space-y-4">
          <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-sm">
            {(['login','register'] as const).map(m => (
              <button key={m} onClick={() => setMode(m)} className={`flex-1 py-2 transition-colors ${mode===m ? 'bg-[var(--color-primary)] text-white' : 'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>
          <div className="space-y-3">
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Email</label><Input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} /></div>
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Password</label><Input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && handle()} /></div>
          </div>
          {error && <p className="text-xs text-red-400 bg-red-900/20 border border-red-900/30 rounded-md px-3 py-2">{error}</p>}
          <Button variant="primary" className="w-full" loading={loading} onClick={handle}>
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </Button>
        </div>
      </div>
    </div>
  )
}
