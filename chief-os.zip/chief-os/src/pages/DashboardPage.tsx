import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { timeAgo, formatDate } from '@/lib/utils'
import { CheckSquare, Brain, FileText, Bot, MessageSquare, Calendar } from 'lucide-react'

export function DashboardPage() {
  const { user } = useAuth()
  const [stats, setStats] = useState({ tasks: 0, done: 0, memories: 0, notes: 0, agents: 0 })
  const [messages, setMessages] = useState<any[]>([])
  const [events, setEvents] = useState<any[]>([])
  const [activeTasks, setActiveTasks] = useState<any[]>([])
  const [logs, setLogs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    Promise.all([
      supabase.from('tasks').select('id,status').eq('user_id', user.id),
      supabase.from('chief_memory').select('id').eq('user_id', user.id),
      supabase.from('notes').select('id').eq('user_id', user.id),
      supabase.from('agents').select('id').eq('user_id', user.id),
      supabase.from('chief_messages').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
      supabase.from('calendar_events').select('*').eq('user_id', user.id).gte('event_date', new Date().toISOString().split('T')[0]).order('event_date').limit(3),
      supabase.from('tasks').select('*').eq('user_id', user.id).eq('status', 'in_progress').limit(5),
      supabase.from('agent_logs').select('*,agents(name,emoji)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
    ]).then(([t, m, n, a, msg, ev, at, lg]) => {
      const tasks = t.data || []
      setStats({ tasks: tasks.length, done: tasks.filter(x => x.status === 'done').length, memories: (m.data||[]).length, notes: (n.data||[]).length, agents: (a.data||[]).length })
      setMessages(msg.data || [])
      setEvents(ev.data || [])
      setActiveTasks(at.data || [])
      setLogs(lg.data || [])
      setLoading(false)
    })
  }, [user])

  const statCards = [
    { label: 'Total Tasks', value: stats.tasks, icon: CheckSquare, color: 'text-amber-400' },
    { label: 'Completed', value: stats.done, icon: CheckSquare, color: 'text-green-400' },
    { label: 'Memories', value: stats.memories, icon: Brain, color: 'text-purple-400' },
    { label: 'Notes', value: stats.notes, icon: FileText, color: 'text-blue-400' },
    { label: 'Agents', value: stats.agents, icon: Bot, color: 'text-teal-400' },
  ]

  if (loading) return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">{[...Array(5)].map((_,i) => <div key={i} className="skeleton h-20 rounded-xl" />)}</div>
      <div className="grid md:grid-cols-2 gap-4">{[...Array(4)].map((_,i) => <div key={i} className="skeleton h-40 rounded-xl" />)}</div>
    </div>
  )

  return (
    <div className="p-6 space-y-6 max-w-6xl">
      <div><h1 className="text-xl font-bold text-[var(--color-text)]">Dashboard</h1><p className="text-sm text-[var(--color-text-muted)]">Overview of your Chief OS</p></div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {statCards.map(s => (
          <div key={s.label} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
            <s.icon size={18} className={s.color} />
            <div className="text-2xl font-bold text-[var(--color-text)] mt-2">{s.value}</div>
            <div className="text-xs text-[var(--color-text-muted)]">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <Section title="Recent Messages" icon={<MessageSquare size={15} />}>
          {messages.length === 0 ? <Empty text="No messages yet" /> : messages.map(m => (
            <div key={m.id} className="flex gap-2 py-2 border-b border-[var(--color-border)] last:border-0">
              <span className={`text-xs px-1.5 py-0.5 rounded font-medium shrink-0 ${m.role==='user'?'bg-teal-900/40 text-teal-300':'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]'}`}>{m.role==='user'?'You':'Chief'}</span>
              <span className="text-sm text-[var(--color-text-muted)] truncate flex-1">{m.content}</span>
              <span className="text-xs text-[var(--color-text-faint)] shrink-0">{timeAgo(m.created_at)}</span>
            </div>
          ))}
        </Section>
        <Section title="Upcoming Events" icon={<Calendar size={15} />}>
          {events.length === 0 ? <Empty text="No upcoming events" /> : events.map(e => (
            <div key={e.id} className="py-2 border-b border-[var(--color-border)] last:border-0">
              <div className="text-sm font-medium text-[var(--color-text)]">{e.title}</div>
              <div className="text-xs text-[var(--color-text-muted)]">{formatDate(e.event_date)} {e.event_time && `at ${e.event_time.slice(0,5)}`}</div>
            </div>
          ))}
        </Section>
        <Section title="Active Tasks" icon={<CheckSquare size={15} />}>
          {activeTasks.length === 0 ? <Empty text="No active tasks" /> : activeTasks.map(t => (
            <div key={t.id} className="py-2 border-b border-[var(--color-border)] last:border-0">
              <div className="text-sm text-[var(--color-text)]">{t.title}</div>
              <div className="text-xs text-[var(--color-text-muted)] capitalize">{t.priority} priority · {t.domain}</div>
            </div>
          ))}
        </Section>
        <Section title="Agent Activity" icon={<Bot size={15} />}>
          {logs.length === 0 ? <Empty text="No agent activity yet" /> : logs.map(l => (
            <div key={l.id} className="flex items-start gap-2 py-2 border-b border-[var(--color-border)] last:border-0">
              <span className="text-base shrink-0">{(l.agents as any)?.emoji || '🤖'}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-[var(--color-text)]">{l.action}</div>
                {l.detail && <div className="text-xs text-[var(--color-text-muted)] truncate">{l.detail}</div>}
              </div>
              <span className="text-xs text-[var(--color-text-faint)] shrink-0">{timeAgo(l.created_at)}</span>
            </div>
          ))}
        </Section>
      </div>
    </div>
  )
}

function Section({ title, icon, children }: { title: string; icon: any; children: any }) {
  return (
    <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3 text-[var(--color-text-muted)]">{icon}<span className="text-sm font-medium text-[var(--color-text)]">{title}</span></div>
      {children}
    </div>
  )
}
function Empty({ text }: { text: string }) {
  return <div className="py-6 text-center text-sm text-[var(--color-text-faint)]">{text}</div>
}
