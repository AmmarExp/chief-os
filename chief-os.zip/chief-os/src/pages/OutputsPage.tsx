import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { timeAgo } from '@/lib/utils'
import { FolderOpen } from 'lucide-react'

export function OutputsPage() {
  const { user } = useAuth()
  const [outputs, setOutputs] = useState<any[]>([])
  const [expanded, setExpanded] = useState<string|null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    supabase.from('task_outputs').select('*,tasks(title),agents(name,emoji)').eq('user_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { setOutputs(data||[]); setLoading(false) })
  }, [user])

  if (loading) return <div className="p-6 space-y-3">{[...Array(5)].map((_,i) => <div key={i} className="skeleton h-16 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-5"><h1 className="text-xl font-bold text-[var(--color-text)]">Outputs</h1><p className="text-sm text-[var(--color-text-muted)]">Results from agent tasks</p></div>
      {outputs.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]"><FolderOpen size={40} className="mx-auto mb-2 opacity-30" /><p>No outputs yet.</p></div>
      ) : (
        <div className="space-y-2">
          {outputs.map(o => (
            <div key={o.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl overflow-hidden">
              <button className="flex items-center gap-3 px-4 py-3 w-full text-left" onClick={() => setExpanded(expanded===o.id?null:o.id)}>
                <span className="text-lg">{(o.agents as any)?.emoji||'📄'}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-[var(--color-text)] truncate">{(o.tasks as any)?.title||'Untitled task'}</div>
                  <div className="text-xs text-[var(--color-text-muted)]">{(o.agents as any)?.name||'Agent'} · Stage {o.stage} · {timeAgo(o.created_at)}</div>
                </div>
              </button>
              {expanded === o.id && <div className="border-t border-[var(--color-border)] px-4 py-3 bg-[var(--color-surface-2)]"><p className="text-sm text-[var(--color-text-muted)] whitespace-pre-wrap">{o.content}</p></div>}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
