import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Dialog } from '@/components/ui/dialog'
import { Trash2, Plus, Brain } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

const CATS = ['all','preference','fact','reminder','habit','skill']
const CAT_COLOR: Record<string,string> = { preference:'bg-blue-900/40 text-blue-300', fact:'bg-teal-900/40 text-teal-300', reminder:'bg-amber-900/40 text-amber-300', habit:'bg-green-900/40 text-green-300', skill:'bg-purple-900/40 text-purple-300' }

export function MemoryPage() {
  const { user } = useAuth()
  const [memories, setMemories] = useState<any[]>([])
  const [cat, setCat] = useState('all')
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ content:'', category:'fact' })

  const load = async () => {
    if (!user) return
    const { data } = await supabase.from('chief_memory').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
    setMemories(data||[]); setLoading(false)
  }
  useEffect(() => { load() }, [user])

  const add = async () => {
    if (!user || !form.content.trim()) return
    await supabase.from('chief_memory').insert({ ...form, user_id: user.id, source: 'manual' })
    setOpen(false); setForm({ content:'', category:'fact' }); load()
  }

  const del = async (id: string) => {
    await supabase.from('chief_memory').delete().eq('id', id)
    setMemories(prev => prev.filter(m => m.id !== id))
  }

  const filtered = cat === 'all' ? memories : memories.filter(m => m.category === cat)

  if (loading) return <div className="p-6 space-y-2">{[...Array(6)].map((_,i) => <div key={i} className="skeleton h-12 rounded-lg" />)}</div>

  return (
    <div className="p-6 max-w-3xl">
      <div className="flex items-center justify-between mb-5">
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Memory</h1><p className="text-sm text-[var(--color-text-muted)]">{memories.length} memories stored</p></div>
        <Button variant="primary" size="sm" onClick={() => setOpen(true)}><Plus size={15} />Add Memory</Button>
      </div>
      <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-xs mb-5 w-fit flex-wrap">
        {CATS.map(c => <button key={c} onClick={() => setCat(c)} className={`px-3 py-1.5 capitalize transition-colors ${cat===c?'bg-[var(--color-primary)] text-white':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{c}</button>)}
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]"><Brain size={40} className="mx-auto mb-2 opacity-30" /><p>Chief has no memories yet.<br/>Add facts about yourself to personalize responses.</p></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(m => (
            <div key={m.id} className="flex items-start gap-3 px-4 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl">
              <span className={`text-xs px-2 py-0.5 rounded font-medium shrink-0 mt-0.5 ${CAT_COLOR[m.category]||'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]'}`}>{m.category}</span>
              <p className="text-sm text-[var(--color-text-muted)] flex-1">{m.content}</p>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs text-[var(--color-text-faint)]">{timeAgo(m.created_at)}</span>
                <button onClick={() => del(m.id)} className="p-1 text-[var(--color-text-faint)] hover:text-red-400 rounded"><Trash2 size={13}/></button>
              </div>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onClose={() => setOpen(false)} title="Add Memory">
        <div className="space-y-3">
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">What should Chief remember?</label><Textarea value={form.content} onChange={e => setForm(p=>({...p,content:e.target.value}))} placeholder="e.g. I prefer concise responses. I work in HR in Saudi Arabia." rows={4} /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Category</label>
            <select value={form.category} onChange={e => setForm(p=>({...p,category:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              {['preference','fact','reminder','habit','skill'].map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          <div className="flex gap-2 pt-2"><Button variant="secondary" className="flex-1" onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" className="flex-1" onClick={add}>Save Memory</Button></div>
        </div>
      </Dialog>
    </div>
  )
}
