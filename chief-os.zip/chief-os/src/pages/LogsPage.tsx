import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { ScrollText } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

export function LogsPage() {
  const { user } = useAuth()
  const [logs, setLogs] = useState<any[]>([])
  const [agents, setAgents] = useState<any[]>([])
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    Promise.all([
      supabase.from('agent_logs').select('*,agents(name,emoji)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(100),
      supabase.from('agents').select('id,name,emoji').eq('user_id', user.id),
    ]).then(([l, a]) => { setLogs(l.data||[]); setAgents(a.data||[]); setLoading(false) })
  }, [user])

  const filtered = filter === 'all' ? logs : logs.filter(l => l.agent_id === filter)

  if (loading) return <div className="p-6 space-y-2">{[...Array(8)].map((_,i) => <div key={i} className="skeleton h-10 rounded-lg" />)}</div>

  return (
    <div className="p-6 max-w-3xl">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/20 flex items-center justify-center"><ScrollText size={20} className="text-[var(--color-primary)]" /></div>
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Activity Logs</h1><p className="text-sm text-[var(--color-text-muted)]">{filtered.length} entries</p></div>
      </div>
      {agents.length > 0 && (
        <div className="flex gap-2 mb-4 flex-wrap">
          <button onClick={() => setFilter('all')} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${filter==='all'?'bg-[var(--color-primary)] text-white border-[var(--color-primary)]':'border-[var(--color-border)] text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>All</button>
          {agents.map((a:any) => <button key={a.id} onClick={() => setFilter(a.id)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${filter===a.id?'bg-[var(--color-primary)] text-white border-[var(--color-primary)]':'border-[var(--color-border)] text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{a.emoji} {a.name}</button>)}
        </div>
      )}
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]"><ScrollText size={40} className="mx-auto mb-2 opacity-30" /><p>No agent activity yet.</p></div>
      ) : (
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl overflow-hidden divide-y divide-[var(--color-border)]">
          {filtered.map(l => (
            <div key={l.id} className="flex items-start gap-3 px-4 py-3">
              <span className="text-base shrink-0 mt-0.5">{(l.agents as any)?.emoji||'🤖'}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-[var(--color-text)]">{l.action}</div>
                {l.detail && <div className="text-xs text-[var(--color-text-muted)] truncate">{l.detail}</div>}
              </div>
              <span className="text-xs text-[var(--color-text-faint)] shrink-0">{timeAgo(l.created_at)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
