import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Sparkles, CheckCircle } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

export function SoulPage() {
  const { user } = useAuth()
  const [chief, setChief] = useState<any>(null)
  const [form, setForm] = useState({ system_prompt:'', soul_prompt:'', memory_context:'' })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!user) return
    supabase.from('agents').select('*').eq('user_id', user.id).eq('is_chief', true).single()
      .then(({ data }) => { if (data) { setChief(data); setForm({ system_prompt: data.system_prompt||'', soul_prompt: data.soul_prompt||'', memory_context: data.memory_context||'' }) }; setLoading(false) })
  }, [user])

  const save = async () => {
    if (!chief) return
    setSaving(true)
    await supabase.from('agents').update(form).eq('id', chief.id)
    setSaving(false); setSaved(true)
    setTimeout(() => setSaved(false), 3000)
    setChief((prev: any) => ({ ...prev, ...form }))
  }

  if (loading) return <div className="p-6 space-y-4">{[...Array(3)].map((_,i) => <div key={i} className="skeleton h-36 rounded-xl" />)}</div>

  const fields = [
    { key:'system_prompt', label:'Personality & Tone', desc:'How should Chief speak to you?', placeholder:"You are Chief, my personal AI assistant. Be concise, direct, and friendly.\nAlways respond in the same language I use." },
    { key:'soul_prompt', label:'About Me', desc:'What should Chief know about you?', placeholder:"I work in HR Compensation & Benefits in Saudi Arabia.\nI build web apps with Lovable and Supabase.\nI use Excel frequently." },
    { key:'memory_context', label:'Behavior Rules', desc:'Rules Chief must always follow:', placeholder:"Always ask before deleting anything.\nKeep replies under 3 paragraphs unless I ask for more.\nNever give generic advice — be specific." },
  ]

  return (
    <div className="p-6 max-w-2xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/20 flex items-center justify-center"><Sparkles size={20} className="text-[var(--color-primary)]" /></div>
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Chief's Soul</h1><p className="text-sm text-[var(--color-text-muted)]">Define how Chief thinks and communicates</p></div>
      </div>
      <div className="space-y-5">
        {fields.map(f => (
          <div key={f.key} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
            <div className="mb-1"><span className="text-sm font-semibold text-[var(--color-text)]">{f.label}</span></div>
            <div className="text-xs text-[var(--color-text-muted)] mb-3">{f.desc}</div>
            <Textarea value={(form as any)[f.key]} onChange={e => setForm(p=>({...p,[f.key]:e.target.value}))} placeholder={f.placeholder} rows={5} />
          </div>
        ))}
      </div>
      <div className="flex items-center gap-3 mt-5">
        <Button variant="primary" onClick={save} loading={saving} size="lg">Save Soul</Button>
        {saved && <div className="flex items-center gap-1.5 text-sm text-green-400"><CheckCircle size={15} />Saved!</div>}
        {chief?.updated_at && <span className="text-xs text-[var(--color-text-faint)] ml-auto">Last saved {timeAgo(chief.updated_at)}</span>}
      </div>
    </div>
  )
}
