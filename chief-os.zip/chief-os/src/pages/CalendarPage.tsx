import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog } from '@/components/ui/dialog'
import { domainBadge } from '@/components/ui/badge'
import { Plus, Trash2, Calendar } from 'lucide-react'

export function CalendarPage() {
  const { user } = useAuth()
  const [events, setEvents] = useState<any[]>([])
  const [domain, setDomain] = useState('all')
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ title:'', description:'', event_date:'', event_time:'', all_day:false, domain:'personal' })
  const today = new Date().toISOString().split('T')[0]

  const load = async () => {
    if (!user) return
    const { data } = await supabase.from('calendar_events').select('*').eq('user_id', user.id).order('event_date').order('event_time')
    setEvents(data || []); setLoading(false)
  }
  useEffect(() => { load() }, [user])

  const add = async () => {
    if (!user || !form.title.trim() || !form.event_date) return
    await supabase.from('calendar_events').insert({ ...form, user_id: user.id, event_time: form.all_day ? null : form.event_time || null })
    setOpen(false); setForm({ title:'', description:'', event_date:'', event_time:'', all_day:false, domain:'personal' }); load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete event?')) return
    await supabase.from('calendar_events').delete().eq('id', id)
    setEvents(prev => prev.filter(e => e.id !== id))
  }

  const filtered = domain === 'all' ? events : events.filter(e => e.domain === domain)
  const upcoming = filtered.filter(e => e.event_date >= today)
  const past = filtered.filter(e => e.event_date < today)

  if (loading) return <div className="p-6 space-y-3">{[...Array(4)].map((_,i) => <div key={i} className="skeleton h-16 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-3xl">
      <div className="flex items-center justify-between mb-5">
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Calendar</h1><p className="text-sm text-[var(--color-text-muted)]">{upcoming.length} upcoming events</p></div>
        <Button variant="primary" size="sm" onClick={() => setOpen(true)}><Plus size={15} />Add Event</Button>
      </div>
      <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-xs mb-5 w-fit">
        {['all','work','projects','personal'].map(d => <button key={d} onClick={() => setDomain(d)} className={`px-3 py-1.5 capitalize transition-colors ${domain===d?'bg-[var(--color-primary)] text-white':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{d}</button>)}
      </div>
      {upcoming.length === 0 && past.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]">
          <Calendar size={40} className="mx-auto mb-2 opacity-30" />
          <p>No events yet. Schedule your first event.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {upcoming.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-[var(--color-text-muted)] uppercase tracking-wider mb-2">Upcoming</div>
              <div className="space-y-2">{upcoming.map(e => <EventRow key={e.id} event={e} today={today} onDelete={del} />)}</div>
            </div>
          )}
          {past.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-[var(--color-text-muted)] uppercase tracking-wider mb-2">Past</div>
              <div className="space-y-2 opacity-60">{past.map(e => <EventRow key={e.id} event={e} today={today} onDelete={del} />)}</div>
            </div>
          )}
        </div>
      )}
      <Dialog open={open} onClose={() => setOpen(false)} title="Add Event">
        <div className="space-y-3">
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Title *</label><Input value={form.title} onChange={e => setForm(p=>({...p,title:e.target.value}))} placeholder="Event title" /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Description</label><Input value={form.description} onChange={e => setForm(p=>({...p,description:e.target.value}))} placeholder="Optional" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Date *</label><Input type="date" value={form.event_date} onChange={e => setForm(p=>({...p,event_date:e.target.value}))} /></div>
            {!form.all_day && <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Time</label><Input type="time" value={form.event_time} onChange={e => setForm(p=>({...p,event_time:e.target.value}))} /></div>}
          </div>
          <div className="flex items-center gap-2"><input type="checkbox" id="allday" checked={form.all_day} onChange={e => setForm(p=>({...p,all_day:e.target.checked}))} /><label htmlFor="allday" className="text-sm text-[var(--color-text-muted)]">All day event</label></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Domain</label>
            <select value={form.domain} onChange={e => setForm(p=>({...p,domain:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              {['work','projects','personal'].map(d=><option key={d} value={d}>{d}</option>)}</select></div>
          <div className="flex gap-2 pt-2"><Button variant="secondary" className="flex-1" onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" className="flex-1" onClick={add}>Add Event</Button></div>
        </div>
      </Dialog>
    </div>
  )
}

function EventRow({ event: e, today, onDelete }: { event: any; today: string; onDelete: (id:string)=>void }) {
  const isToday = e.event_date === today
  return (
    <div className={`flex items-center gap-3 px-4 py-3 bg-[var(--color-surface)] border rounded-xl ${isToday ? 'border-[var(--color-primary)] ring-1 ring-[var(--color-primary)]/20' : 'border-[var(--color-border)]'}`}>
      <div className="shrink-0 text-center w-12">
        <div className="text-xs text-[var(--color-text-faint)]">{new Date(e.event_date+'T00:00:00').toLocaleDateString('en',{month:'short'})}</div>
        <div className={`text-lg font-bold ${isToday ? 'text-[var(--color-primary)]' : 'text-[var(--color-text)]'}`}>{new Date(e.event_date+'T00:00:00').getDate()}</div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-[var(--color-text)]">{e.title}</div>
        <div className="flex items-center gap-2 mt-0.5">
          {isToday && <span className="text-xs text-[var(--color-primary)] font-medium">Today</span>}
          {!e.all_day && e.event_time && <span className="text-xs text-[var(--color-text-muted)]">{e.event_time.slice(0,5)}</span>}
          {e.all_day && <span className="text-xs text-[var(--color-text-muted)]">All day</span>}
          {domainBadge(e.domain)}
        </div>
        {e.description && <div className="text-xs text-[var(--color-text-faint)] mt-0.5 truncate">{e.description}</div>}
      </div>
      <button onClick={() => onDelete(e.id)} className="p-1.5 text-[var(--color-text-faint)] hover:text-red-400 rounded-md hover:bg-[var(--color-surface-2)]"><Trash2 size={14}/></button>
    </div>
  )
}
