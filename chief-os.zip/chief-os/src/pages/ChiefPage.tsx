import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Send, Brain, X, Trash2, Crown } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

export function ChiefPage() {
  const { user, session } = useAuth()
  const [messages, setMessages] = useState<any[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [showContext, setShowContext] = useState(false)
  const [soul, setSoul] = useState<any>(null)
  const [memories, setMemories] = useState<any[]>([])
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!user) return
    supabase.from('chief_messages').select('*').eq('user_id', user.id).order('created_at').then(({ data }) => setMessages(data || []))
    supabase.from('agents').select('*').eq('user_id', user.id).eq('is_chief', true).single().then(({ data }) => setSoul(data))
    supabase.from('chief_memory').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(8).then(({ data }) => setMemories(data || []))

    const sub = supabase.channel('chief-messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chief_messages', filter: `user_id=eq.${user.id}` },
        (payload) => setMessages(prev => [...prev, payload.new]))
      .subscribe()
    return () => { supabase.removeChannel(sub) }
  }, [user])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async () => {
    if (!input.trim() || loading) return
    const text = input.trim(); setInput(''); setLoading(true)
    await supabase.from('chief_messages').insert({ user_id: user!.id, content: text, role: 'user' })
    try {
      await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chief-ai`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ message: text }),
      })
    } catch (e) {
      await supabase.from('chief_messages').insert({ user_id: user!.id, content: 'Sorry, I encountered an error. Please try again.', role: 'assistant' })
    }
    setLoading(false)
  }

  const clearChat = async () => {
    if (!user || !confirm('Clear all messages?')) return
    await supabase.from('chief_messages').delete().eq('user_id', user.id)
    setMessages([])
  }

  const catColor: Record<string,string> = { preference:'bg-blue-900/40 text-blue-300', fact:'bg-teal-900/40 text-teal-300', reminder:'bg-amber-900/40 text-amber-300', habit:'bg-green-900/40 text-green-300', skill:'bg-purple-900/40 text-purple-300' }

  return (
    <div className="flex h-full">
      <div className="flex-1 flex flex-col h-full min-w-0">
        <div className="flex items-center justify-between px-5 py-3 border-b border-[var(--color-border)] bg-[var(--color-surface)] shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[var(--color-primary)] flex items-center justify-center"><Crown size={14} className="text-white" /></div>
            <div><div className="text-sm font-semibold text-[var(--color-text)]">Chief</div><div className="text-xs text-[var(--color-text-muted)]">Your AI assistant</div></div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={clearChat} title="Clear chat"><Trash2 size={15} /></Button>
            <Button variant="ghost" size="sm" onClick={() => setShowContext(!showContext)} className="gap-1.5"><Brain size={14} />Context</Button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {messages.length === 0 && !loading && (
            <div className="flex flex-col items-center justify-center h-full text-center py-16">
              <div className="w-12 h-12 rounded-2xl bg-[var(--color-primary)] flex items-center justify-center mb-3"><Crown size={22} className="text-white" /></div>
              <div className="text-[var(--color-text)] font-medium mb-1">Hello! I'm Chief</div>
              <div className="text-sm text-[var(--color-text-muted)] max-w-xs">Your personal AI assistant. Ask me anything or give me a task to work on.</div>
            </div>
          )}
          {messages.map(m => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-[var(--color-primary)] text-white rounded-br-sm' : 'bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text)] rounded-bl-sm'}`}>
                <div className="whitespace-pre-wrap">{m.content}</div>
                <div className={`text-xs mt-1 ${m.role === 'user' ? 'text-white/60' : 'text-[var(--color-text-faint)]'}`}>{timeAgo(m.created_at)}</div>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl rounded-bl-sm px-4 py-3 flex gap-1">
                {[0,1,2].map(i => <span key={i} className="w-2 h-2 bg-[var(--color-text-muted)] rounded-full animate-bounce" style={{ animationDelay: `${i*0.15}s` }} />)}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
        <div className="px-4 py-3 border-t border-[var(--color-border)] bg-[var(--color-surface)] shrink-0">
          <div className="flex gap-2 items-end">
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
              placeholder="Message Chief... (Enter to send, Shift+Enter for new line)"
              className="flex-1 bg-[var(--color-surface-2)] border border-[var(--color-border)] rounded-xl px-4 py-2.5 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-faint)] focus:outline-none focus:border-[var(--color-primary)] resize-none max-h-32" rows={1} />
            <Button variant="primary" size="icon" onClick={send} loading={loading} className="rounded-xl shrink-0 h-10 w-10"><Send size={16} /></Button>
          </div>
        </div>
      </div>
      {showContext && (
        <div className="w-72 shrink-0 border-l border-[var(--color-border)] bg-[var(--color-surface)] flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--color-border)]">
            <span className="text-sm font-semibold text-[var(--color-text)]">🧠 Context</span>
            <button onClick={() => setShowContext(false)} className="p-1 rounded text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-surface-2)]"><X size={14} /></button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {soul && (
              <div>
                <div className="text-xs font-semibold text-[var(--color-text-muted)] uppercase tracking-wider mb-2">Soul</div>
                {soul.system_prompt && <p className="text-xs text-[var(--color-text-muted)] mb-1 line-clamp-3">{soul.system_prompt}</p>}
                {soul.soul_prompt && <p className="text-xs text-[var(--color-text-faint)] line-clamp-2">{soul.soul_prompt}</p>}
              </div>
            )}
            <div>
              <div className="text-xs font-semibold text-[var(--color-text-muted)] uppercase tracking-wider mb-2">Memories ({memories.length})</div>
              {memories.length === 0 ? <p className="text-xs text-[var(--color-text-faint)]">No memories yet</p> :
                memories.map(m => (
                  <div key={m.id} className="flex items-start gap-2 mb-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded shrink-0 ${catColor[m.category] || 'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]'}`}>{m.category}</span>
                    <span className="text-xs text-[var(--color-text-muted)] line-clamp-2">{m.content}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
