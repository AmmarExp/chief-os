import { Wrench } from 'lucide-react'
const SKILLS = [
  { name:'Web Search', desc:'Search the web for real-time information', status:'coming', icon:'🔍' },
  { name:'File Analysis', desc:'Analyze uploaded documents and files', status:'coming', icon:'📄' },
  { name:'Code Execution', desc:'Write and run code snippets', status:'coming', icon:'💻' },
  { name:'Telegram', desc:'Send and receive messages via Telegram', status:'active', icon:'✈️' },
  { name:'Email', desc:'Read and send emails on your behalf', status:'coming', icon:'📧' },
  { name:'Calendar Sync', desc:'Sync with Google Calendar or Outlook', status:'coming', icon:'📅' },
  { name:'Notion', desc:'Read and write Notion pages', status:'coming', icon:'📓' },
  { name:'GitHub', desc:'Manage repositories and pull requests', status:'coming', icon:'🐙' },
]
export function SkillsPage() {
  return (
    <div className="p-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/20 flex items-center justify-center"><Wrench size={20} className="text-[var(--color-primary)]" /></div>
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Skills</h1><p className="text-sm text-[var(--color-text-muted)]">Capabilities available to Chief and your agents</p></div>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {SKILLS.map(s => (
          <div key={s.name} className="flex items-start gap-3 p-4 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl">
            <span className="text-2xl shrink-0">{s.icon}</span>
            <div className="flex-1">
              <div className="flex items-center gap-2"><span className="text-sm font-medium text-[var(--color-text)]">{s.name}</span>
                <span className={`text-xs px-2 py-0.5 rounded font-medium ${s.status==='active'?'bg-green-900/40 text-green-300':'bg-[var(--color-surface-2)] text-[var(--color-text-faint)]'}`}>{s.status==='active'?'Active':'Coming Soon'}</span>
              </div>
              <p className="text-xs text-[var(--color-text-muted)] mt-0.5">{s.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
