import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog } from '@/components/ui/dialog'
import { statusBadge, priorityBadge, domainBadge } from '@/components/ui/badge'
import { Plus, Trash2, ChevronDown, ChevronUp, RefreshCw } from 'lucide-react'
import { formatDate, timeAgo } from '@/lib/utils'

const DOMAINS = ['all','work','projects','personal']
const STATUSES = ['all','todo','in_progress','done','failed']
const PRIORITIES = ['low','medium','high']

export function TasksPage() {
  const { user } = useAuth()
  const [tasks, setTasks] = useState<any[]>([])
  const [agents, setAgents] = useState<any[]>([])
  const [domain, setDomain] = useState('all')
  const [status, setStatus] = useState('all')
  const [open, setOpen] = useState(false)
  const [expanded, setExpanded] = useState<string|null>(null)
  const [executions, setExecutions] = useState<any[]>([])
  const [outputs, setOutputs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ title:'', description:'', priority:'medium', domain:'personal', agent_id:'', is_recurring:false, recurrence_pattern:'daily', due_date:'' })

  const load = async () => {
    if (!user) return
    const [t, a] = await Promise.all([
      supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('agents').select('id,name,emoji').eq('user_id', user.id),
    ])
    setTasks(t.data || [])
    setAgents(a.data || [])
    setLoading(false)
  }
  useEffect(() => { load() }, [user])

  const expand = async (id: string) => {
    if (expanded === id) { setExpanded(null); return }
    setExpanded(id)
    const [ex, out] = await Promise.all([
      supabase.from('task_executions').select('*').eq('task_id', id).order('run_date', { ascending: false }),
      supabase.from('task_outputs').select('*,agents(name,emoji)').eq('task_id', id).order('stage'),
    ])
    setExecutions(ex.data || [])
    setOutputs(out.data || [])
  }

  const addTask = async () => {
    if (!user || !form.title.trim()) return
    const { data } = await supabase.from('tasks').insert({ ...form, user_id: user.id, agent_id: form.agent_id || null, due_date: form.due_date || null }).select().single()
    if (data) { setTasks(prev => [data, ...prev]); setOpen(false); setForm({ title:'', description:'', priority:'medium', domain:'personal', agent_id:'', is_recurring:false, recurrence_pattern:'daily', due_date:'' }) }
  }

  const updateStatus = async (id: string, s: string) => {
    await supabase.from('tasks').update({ status: s, updated_at: new Date().toISOString() }).eq('id', id)
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: s } : t))
  }

  const deleteTask = async (id: string) => {
    if (!confirm('Delete this task?')) return
    await supabase.from('tasks').delete().eq('id', id)
    setTasks(prev => prev.filter(t => t.id !== id))
  }

  const filtered = tasks.filter(t => (domain === 'all' || t.domain === domain) && (status === 'all' || t.status === status))

  if (loading) return <div className="p-6 space-y-3">{[...Array(5)].map((_,i) => <div key={i} className="skeleton h-16 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-4xl">
      <div className="flex items-center justify-between mb-5">
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Tasks</h1><p className="text-sm text-[var(--color-text-muted)]">{filtered.length} tasks</p></div>
        <Button variant="primary" size="sm" onClick={() => setOpen(true)}><Plus size={15} />Add Task</Button>
      </div>
      <div className="flex gap-2 mb-4 flex-wrap">
        <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-xs">
          {DOMAINS.map(d => <button key={d} onClick={() => setDomain(d)} className={`px-3 py-1.5 capitalize transition-colors ${domain===d?'bg-[var(--color-primary)] text-white':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{d}</button>)}
        </div>
        <div className="flex rounded-lg overflow-hidden border border-[var(--color-border)] text-xs">
          {STATUSES.map(s => <button key={s} onClick={() => setStatus(s)} className={`px-3 py-1.5 capitalize transition-colors ${status===s?'bg-[var(--color-primary)] text-white':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>{s.replace('_',' ')}</button>)}
        </div>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-text-faint)]"><CheckSquareIcon /><p className="mt-2">No tasks yet. Add your first task.</p></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(t => (
            <div key={t.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl overflow-hidden">
              <div className="flex items-center gap-3 px-4 py-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-[var(--color-text)]">{t.title}</span>
                    {t.is_recurring && <RefreshCw size={12} className="text-[var(--color-text-muted)]" />}
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    {statusBadge(t.status)}{priorityBadge(t.priority)}{domainBadge(t.domain)}
                    {t.due_date && <span className="text-xs text-[var(--color-text-faint)]">Due {formatDate(t.due_date)}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <select value={t.status} onChange={e => updateStatus(t.id, e.target.value)} className="text-xs bg-[var(--color-surface-2)] border border-[var(--color-border)] rounded-md px-2 py-1 text-[var(--color-text-muted)]">
                    {['todo','in_progress','done','failed'].map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}
                  </select>
                  <button onClick={() => expand(t.id)} className="p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]">{expanded===t.id?<ChevronUp size={16}/>:<ChevronDown size={16}/>}</button>
                  <button onClick={() => deleteTask(t.id)} className="p-1 text-[var(--color-text-muted)] hover:text-red-400"><Trash2 size={15}/></button>
                </div>
              </div>
              {expanded === t.id && (
                <div className="border-t border-[var(--color-border)] px-4 py-3 bg-[var(--color-surface-2)] space-y-3">
                  {t.description && <p className="text-sm text-[var(--color-text-muted)]">{t.description}</p>}
                  {outputs.length > 0 && <div><div className="text-xs font-semibold text-[var(--color-text-muted)] mb-1">Outputs</div>{outputs.map(o => <div key={o.id} className="text-xs bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg p-2 mb-1"><span className="text-[var(--color-text-faint)] mr-1">Stage {o.stage}:</span><span className="text-[var(--color-text-muted)]">{o.content}</span></div>)}</div>}
                  {executions.length > 0 && <div><div className="text-xs font-semibold text-[var(--color-text-muted)] mb-1">Execution Log</div>{executions.map(e => <div key={e.id} className="flex gap-2 text-xs text-[var(--color-text-muted)] py-1"><span className="text-[var(--color-text-faint)]">{e.run_date}</span><span className={e.status==='done'?'text-green-400':e.status==='failed'?'text-red-400':'text-amber-400'}>{e.status}</span>{e.output&&<span className="truncate">{e.output}</span>}</div>)}</div>}
                  <div className="text-xs text-[var(--color-text-faint)]">Created {timeAgo(t.created_at)}</div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onClose={() => setOpen(false)} title="Add Task">
        <div className="space-y-3">
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Title *</label><Input value={form.title} onChange={e => setForm(p => ({...p,title:e.target.value}))} placeholder="Task title" /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Description</label><Textarea value={form.description} onChange={e => setForm(p => ({...p,description:e.target.value}))} placeholder="Optional details" rows={3} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Priority</label>
              <select value={form.priority} onChange={e => setForm(p => ({...p,priority:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}</select></div>
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Domain</label>
              <select value={form.domain} onChange={e => setForm(p => ({...p,domain:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
                {['work','projects','personal'].map(d => <option key={d} value={d}>{d}</option>)}</select></div>
          </div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Assign Agent</label>
            <select value={form.agent_id} onChange={e => setForm(p => ({...p,agent_id:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              <option value="">No agent</option>{agents.map(a => <option key={a.id} value={a.id}>{a.emoji} {a.name}</option>)}</select></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Due Date</label><Input type="date" value={form.due_date} onChange={e => setForm(p => ({...p,due_date:e.target.value}))} /></div>
          <div className="flex items-center gap-2">
            <input type="checkbox" id="recurring" checked={form.is_recurring} onChange={e => setForm(p => ({...p,is_recurring:e.target.checked}))} className="rounded" />
            <label htmlFor="recurring" className="text-sm text-[var(--color-text-muted)]">Recurring task</label>
          </div>
          {form.is_recurring && <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Recurrence</label>
            <select value={form.recurrence_pattern} onChange={e => setForm(p => ({...p,recurrence_pattern:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              {['daily','weekly','monthly'].map(r => <option key={r} value={r}>{r}</option>)}</select></div>}
          <div className="flex gap-2 pt-2">
            <Button variant="secondary" className="flex-1" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" className="flex-1" onClick={addTask}>Add Task</Button>
          </div>
        </div>
      </Dialog>
    </div>
  )
}
function CheckSquareIcon() { return <svg className="w-10 h-10 mx-auto text-[var(--color-text-faint)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> }
