import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog } from '@/components/ui/dialog'
import { Pencil, Play, Pause } from 'lucide-react'

const STATUS_COLOR: Record<string,string> = { idle:'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]', running:'bg-green-900/40 text-green-300', paused:'bg-amber-900/40 text-amber-300' }
const MODELS = ['gemini-2.0-flash','gemini-1.5-pro','gpt-4o','gpt-4o-mini','claude-3-5-sonnet']

export function AgentsPage() {
  const { user } = useAuth()
  const [agents, setAgents] = useState<any[]>([])
  const [logs, setLogs] = useState<Record<string,any[]>>({})
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ name:'', role:'', emoji:'🤖', model:'gemini-2.0-flash' })
  const [loading, setLoading] = useState(true)

  const load = async () => {
    if (!user) return
    const { data: a } = await supabase.from('agents').select('*').eq('user_id', user.id)
    setAgents(a || [])
    const agentIds = (a||[]).map((x:any) => x.id)
    if (agentIds.length > 0) {
      const { data: l } = await supabase.from('agent_logs').select('*').in('agent_id', agentIds).order('created_at', { ascending: false }).limit(20)
      const grouped: Record<string,any[]> = {}
      ;(l||[]).forEach((log:any) => { if (!grouped[log.agent_id]) grouped[log.agent_id] = []; grouped[log.agent_id].push(log) })
      setLogs(grouped)
    }
    setLoading(false)
  }
  useEffect(() => { load() }, [user])

  const openEdit = (a: any) => { setEditing(a); setForm({ name:a.name, role:a.role, emoji:a.emoji, model:a.model }) }

  const save = async () => {
    if (!editing) return
    await supabase.from('agents').update(form).eq('id', editing.id)
    setEditing(null); load()
  }

  const toggleStatus = async (a: any) => {
    const next = a.status === 'running' ? 'idle' : 'running'
    await supabase.from('agents').update({ status: next }).eq('id', a.id)
    setAgents(prev => prev.map(x => x.id === a.id ? { ...x, status: next } : x))
  }

  if (loading) return <div className="p-6 grid md:grid-cols-2 gap-4">{[...Array(4)].map((_,i) => <div key={i} className="skeleton h-48 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-4xl">
      <div className="mb-5"><h1 className="text-xl font-bold text-[var(--color-text)]">Agents</h1><p className="text-sm text-[var(--color-text-muted)]">Your AI agent team</p></div>
      <div className="grid md:grid-cols-2 gap-4">
        {agents.map(a => (
          <div key={a.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl" style={{ background: a.color + '22' }}>{a.emoji}</div>
                <div>
                  <div className="font-semibold text-[var(--color-text)]">{a.name}</div>
                  <div className="text-xs text-[var(--color-text-muted)]">{a.role}</div>
                </div>
              </div>
              <div className="flex gap-1.5">
                <button onClick={() => toggleStatus(a)} className={`p-1.5 rounded-lg transition-colors ${a.status==='running'?'text-green-300 hover:bg-green-900/20':'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]'}`}>
                  {a.status === 'running' ? <Pause size={14}/> : <Play size={14}/>}
                </button>
                <button onClick={() => openEdit(a)} className="p-1.5 rounded-lg text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]"><Pencil size={14}/></button>
              </div>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <span className={`text-xs px-2 py-0.5 rounded font-medium ${STATUS_COLOR[a.status]||STATUS_COLOR.idle}`}>{a.status}</span>
              <span className="text-xs text-[var(--color-text-faint)]">{a.model}</span>
              {a.is_chief && <span className="text-xs px-2 py-0.5 rounded bg-[var(--color-primary)]/20 text-[var(--color-primary)] font-medium">Chief</span>}
            </div>
            {(logs[a.id]||[]).slice(0,3).length > 0 && (
              <div className="border-t border-[var(--color-border)] pt-3 space-y-1">
                <div className="text-xs text-[var(--color-text-faint)] mb-1">Recent activity</div>
                {(logs[a.id]||[]).slice(0,3).map((l:any) => (
                  <div key={l.id} className="text-xs text-[var(--color-text-muted)] truncate">• {l.action}</div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <Dialog open={!!editing} onClose={() => setEditing(null)} title={`Edit ${editing?.name}`}>
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-3">
            <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Emoji</label><Input value={form.emoji} onChange={e => setForm(p=>({...p,emoji:e.target.value}))} className="text-center text-xl" /></div>
            <div className="col-span-3"><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Name</label><Input value={form.name} onChange={e => setForm(p=>({...p,name:e.target.value}))} /></div>
          </div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Role</label><Input value={form.role} onChange={e => setForm(p=>({...p,role:e.target.value}))} /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Model</label>
            <select value={form.model} onChange={e => setForm(p=>({...p,model:e.target.value}))} className="w-full text-sm bg-[var(--color-surface)] border border-[var(--color-border)] rounded-md px-3 py-2 text-[var(--color-text)]">
              {MODELS.map(m=><option key={m} value={m}>{m}</option>)}</select></div>
          <div className="flex gap-2 pt-2"><Button variant="secondary" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button><Button variant="primary" className="flex-1" onClick={save}>Save</Button></div>
        </div>
      </Dialog>
    </div>
  )
}
