import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Settings, ExternalLink, CheckCircle, Copy } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

export function SettingsPage() {
  const { user, signOut } = useAuth()
  const [profile, setProfile] = useState<any>(null)
  const [linkCode, setLinkCode] = useState('')
  const [codeSaved, setCodeSaved] = useState(false)
  const [loading, setLoading] = useState(true)
  const [fullName, setFullName] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!user) return
    supabase.from('profiles').select('*').eq('id', user.id).single()
      .then(({ data }) => { if (data) { setProfile(data); setFullName(data.full_name||'') }; setLoading(false) })
  }, [user])

  const saveProfile = async () => {
    if (!user) return
    setSaving(true)
    await supabase.from('profiles').update({ full_name: fullName }).eq('id', user.id)
    setSaving(false); setSaved(true); setTimeout(() => setSaved(false), 3000)
  }

  const generateLinkCode = async () => {
    if (!user) return
    const code = Math.random().toString(36).slice(2,8).toUpperCase()
    const expires = new Date(Date.now() + 30 * 60 * 1000).toISOString()
    await supabase.from('profiles').update({ telegram_link_code: code, telegram_link_code_expires_at: expires }).eq('id', user.id)
    setLinkCode(code)
    setCodeSaved(true)
  }

  const copyCode = () => { navigator.clipboard.writeText(linkCode) }

  if (loading) return <div className="p-6 space-y-4">{[...Array(3)].map((_,i) => <div key={i} className="skeleton h-24 rounded-xl" />)}</div>

  return (
    <div className="p-6 max-w-2xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/20 flex items-center justify-center"><Settings size={20} className="text-[var(--color-primary)]" /></div>
        <div><h1 className="text-xl font-bold text-[var(--color-text)]">Settings</h1><p className="text-sm text-[var(--color-text-muted)]">Manage your account and integrations</p></div>
      </div>

      {/* Profile */}
      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-5 mb-4">
        <h2 className="text-sm font-semibold text-[var(--color-text)] mb-4">Profile</h2>
        <div className="space-y-3">
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Email</label><Input value={user?.email||''} disabled /></div>
          <div><label className="text-xs text-[var(--color-text-muted)] mb-1 block">Full Name</label><Input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Your full name" /></div>
          <div className="flex items-center gap-3">
            <Button variant="primary" size="sm" onClick={saveProfile} loading={saving}>Save</Button>
            {saved && <div className="flex items-center gap-1.5 text-sm text-green-400"><CheckCircle size={15} />Saved!</div>}
          </div>
        </div>
      </div>

      {/* Telegram */}
      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-5 mb-4">
        <h2 className="text-sm font-semibold text-[var(--color-text)] mb-1">Telegram Integration</h2>
        <p className="text-xs text-[var(--color-text-muted)] mb-4">Link your Telegram account to chat with Chief from anywhere.</p>
        {profile?.telegram_chat_id ? (
          <div className="flex items-center gap-2 px-3 py-2 bg-green-900/20 border border-green-800/40 rounded-lg">
            <CheckCircle size={15} className="text-green-400" />
            <span className="text-sm text-green-300">Connected · Chat ID {profile.telegram_chat_id}</span>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={generateLinkCode}>Generate Link Code</Button>
              <a href="https://t.me/your_bot_here" target="_blank" rel="noopener noreferrer">
                <Button variant="secondary" size="sm"><ExternalLink size={13}/>Open Bot</Button>
              </a>
            </div>
            {linkCode && (
              <div className="bg-[var(--color-surface-2)] border border-[var(--color-border)] rounded-lg p-3">
                <div className="text-xs text-[var(--color-text-muted)] mb-1">Send this code to the bot with: <code className="text-[var(--color-primary)]">/link</code></div>
                <div className="flex items-center gap-2">
                  <code className="text-2xl font-mono font-bold tracking-widest text-[var(--color-text)]">{linkCode}</code>
                  <button onClick={copyCode} className="p-1.5 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"><Copy size={14}/></button>
                </div>
                <div className="text-xs text-[var(--color-text-faint)] mt-1">Expires in 30 minutes</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Account */}
      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-5">
        <h2 className="text-sm font-semibold text-[var(--color-text)] mb-3">Account</h2>
        <div className="text-xs text-[var(--color-text-muted)] mb-3">Joined {timeAgo(profile?.created_at)}</div>
        <Button variant="secondary" size="sm" onClick={signOut}>Sign Out</Button>
      </div>
    </div>
  )
}
