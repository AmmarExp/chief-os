import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

export type Profile = {
  id: string; display_name: string | null; telegram_chat_id: number | null;
  telegram_link_code: string | null; telegram_link_code_expires_at: string | null; created_at: string;
}
export type Agent = {
  id: string; user_id: string; name: string; role: string; emoji: string; color: string;
  is_chief: boolean; status: string; model: string; system_prompt: string | null;
  soul_prompt: string | null; memory_context: string | null; created_at: string;
}
export type Task = {
  id: string; user_id: string; agent_id: string | null; title: string; description: string | null;
  status: string; priority: string; domain: string; is_recurring: boolean;
  recurrence_pattern: string | null; due_date: string | null; created_at: string; updated_at: string;
}
export type TaskExecution = {
  id: string; task_id: string; user_id: string; agent_id: string | null;
  run_date: string; status: string; output: string | null; created_at: string;
}
export type TaskOutput = {
  id: string; task_id: string; user_id: string; agent_id: string | null;
  content: string; stage: number; created_at: string;
}
export type ChiefMessage = {
  id: string; user_id: string; content: string; role: string;
  telegram_message_id: number | null; created_at: string;
}
export type Note = {
  id: string; user_id: string; title: string; content: string; summary: string | null;
  domain: string; revision_history: any[]; created_at: string; updated_at: string;
}
export type CalendarEvent = {
  id: string; user_id: string; title: string; description: string | null;
  event_date: string; event_time: string | null; all_day: boolean; domain: string; created_at: string;
}
export type Memory = {
  id: string; user_id: string; category: string; content: string; source: string; created_at: string;
}
export type AgentLog = {
  id: string; user_id: string; agent_id: string | null; action: string; detail: string | null; created_at: string;
}
