import { Link, useRouterState } from '@tanstack/react-router'
import { MessageSquare, CheckSquare, FileText, Calendar, FolderOpen, Bot, Brain, Sparkles, Wrench, ScrollText, LayoutDashboard, Settings, LogOut, X, Crown } from 'lucide-react'
import { useAuth } from '@/lib/auth-context'
import { cn } from '@/lib/utils'

const MY_SPACE = [
  { to: '/chief', label: 'Chief Chat', icon: MessageSquare },
  { to: '/tasks', label: 'Tasks', icon: CheckSquare },
  { to: '/notes', label: 'Notes', icon: FileText },
  { to: '/calendar', label: 'Calendar', icon: Calendar },
  { to: '/outputs', label: 'Outputs', icon: FolderOpen },
]
const AGENT_SPACE = [
  { to: '/agents', label: 'Agents', icon: Bot },
  { to: '/memory', label: 'Memory', icon: Brain },
  { to: '/soul', label: 'Soul', icon: Sparkles },
  { to: '/skills', label: 'Skills', icon: Wrench },
  { to: '/logs', label: 'Logs', icon: ScrollText },
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
]

function NavItem({ to, label, icon: Icon }: { to: string; label: string; icon: any }) {
  const path = useRouterState({ select: s => s.location.pathname })
  const active = path === to || path.startsWith(to + '/')
  return (
    <Link to={to} className={cn('flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors', active ? 'bg-[var(--color-primary-light)] text-[var(--color-primary)] font-medium' : 'text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]')}>
      <Icon size={16} />
      <span>{label}</span>
    </Link>
  )
}

function SectionLabel({ label }: { label: string }) {
  return <div className="px-3 py-1.5 text-xs font-semibold tracking-widest text-[var(--color-text-faint)] uppercase mt-4 mb-1">{label}</div>
}

export function Sidebar({ onClose }: { onClose?: () => void }) {
  const { user, signOut } = useAuth()
  return (
    <div className="flex flex-col h-full bg-[var(--color-surface)] border-r border-[var(--color-border)]">
      <div className="flex items-center justify-between px-4 py-4 border-b border-[var(--color-border)]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[var(--color-primary)] flex items-center justify-center">
            <Crown size={14} className="text-white" />
          </div>
          <span className="font-bold text-[var(--color-text)] tracking-tight">Chief OS</span>
        </div>
        {onClose && <button onClick={onClose} className="p-1 rounded-md text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-surface-2)]"><X size={16} /></button>}
      </div>
      <nav className="flex-1 overflow-y-auto px-2 py-2">
        <SectionLabel label="My Space" />
        {MY_SPACE.map(item => <NavItem key={item.to} {...item} />)}
        <SectionLabel label="Agent Space" />
        {AGENT_SPACE.map(item => <NavItem key={item.to} {...item} />)}
      </nav>
      <div className="px-2 py-3 border-t border-[var(--color-border)] space-y-1">
        <NavItem to="/settings" label="Settings" icon={Settings} />
        <button onClick={signOut} className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)] transition-colors w-full">
          <LogOut size={16} /><span>Sign Out</span>
        </button>
        <div className="px-3 py-1 text-xs text-[var(--color-text-faint)] truncate">{user?.email}</div>
      </div>
    </div>
  )
}
