import { ReactNode, useState } from 'react'
import { Menu } from 'lucide-react'
import { Sidebar } from './Sidebar'

export function AppShell({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  return (
    <div className="flex h-screen overflow-hidden bg-[var(--color-bg)]">
      <aside className="hidden md:flex w-60 shrink-0 flex-col"><Sidebar /></aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 flex flex-col z-10"><Sidebar onClose={() => setMobileOpen(false)} /></aside>
        </div>
      )}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="flex md:hidden items-center gap-3 px-4 h-14 border-b border-[var(--color-border)] bg-[var(--color-surface)] shrink-0">
          <button onClick={() => setMobileOpen(true)} className="p-1.5 rounded-md text-[var(--color-text-muted)] hover:bg-[var(--color-surface-2)]"><Menu size={20} /></button>
          <span className="font-bold text-[var(--color-text)]">Chief OS</span>
        </header>
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
    </div>
  )
}
