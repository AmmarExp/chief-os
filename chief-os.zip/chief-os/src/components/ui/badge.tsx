import { cn } from '@/lib/utils'
type Props = { label: string; variant?: 'default'|'work'|'projects'|'personal'|'success'|'warning'|'error'|'todo'|'progress'|'done'|'low'|'medium'|'high' }
const variants: Record<string,string> = {
  default: 'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]',
  work: 'bg-blue-900/40 text-blue-300',
  projects: 'bg-amber-900/40 text-amber-300',
  personal: 'bg-teal-900/40 text-teal-300',
  success: 'bg-green-900/40 text-green-300',
  warning: 'bg-amber-900/40 text-amber-300',
  error: 'bg-red-900/40 text-red-300',
  todo: 'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]',
  progress: 'bg-amber-900/40 text-amber-300',
  done: 'bg-green-900/40 text-green-300',
  low: 'bg-[var(--color-surface-2)] text-[var(--color-text-muted)]',
  medium: 'bg-amber-900/40 text-amber-300',
  high: 'bg-red-900/40 text-red-300',
}
export function Badge({ label, variant = 'default' }: Props) {
  return <span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', variants[variant])}>{label}</span>
}
export function domainBadge(d: string) { return <Badge label={d} variant={d as any} /> }
export function statusBadge(s: string) {
  const map: Record<string,string> = { todo:'todo', in_progress:'progress', done:'done', failed:'error' }
  const label: Record<string,string> = { todo:'Todo', in_progress:'In Progress', done:'Done', failed:'Failed' }
  return <Badge label={label[s]||s} variant={(map[s]||'default') as any} />
}
export function priorityBadge(p: string) { return <Badge label={p.charAt(0).toUpperCase()+p.slice(1)} variant={p as any} /> }
